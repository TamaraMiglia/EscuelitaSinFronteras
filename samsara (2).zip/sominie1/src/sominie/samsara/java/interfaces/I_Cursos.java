/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sominie.samsara.java.interfaces;

/**
 *
 * @author USUARIO
 */
public interface I_Cursos {
     public void add(); 
    public void getOne(int id_colegio);
    public void update();
    public void delete();
    
}
