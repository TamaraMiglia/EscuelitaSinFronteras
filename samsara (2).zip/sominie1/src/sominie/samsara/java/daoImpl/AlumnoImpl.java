 package sominie.samsara.java.daoImpl;
//import sominie.samsara.java.connectors.Conexion;
import java.io.IOException;
import sominie.samsara.java.entities.Alumnos;
import sominie.samsara.java.interfaces.I_Alumno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sominie.samsara.java.connectors.Conexion;



public class AlumnoImpl implements I_Alumno {

    private Connection conn;

    
    public AlumnoImpl(Connection conn) {
        this.conn = conn;
        
    }

    @Override
    public void add(Alumnos alumno) {
        try {
            String query = "INSERT INTO alumnos (id_colegio, nombre, apellido) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
           // ps.setInt(1, alumno.getId_alumnos());
            ps.setInt(1, alumno.getId_colegio());/*aqui como debo tratar al dato? lo mando a llamar de algun lado o lo caoturo por pantalla?*/
            ps.setString(2, alumno.getNombre());
            ps.setString(3, alumno.getApellido());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AlumnoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }

    @Override
    //este metodo debe devolver algo, quedebe ser, una  'COLLECTION'?
    //este metodo deberia llamarse "GETBYID" y debera retornar una lista
    public String getOne( int id_alumno) {
        
        //A DESARROLLAR CUERPO DEL METODO
        // Alumnos alumno = null;
//        String query = "SELECT a.nombre AS nombre_alumno, co.nombre_cole AS nombre_colegio, cu.nombre_curso AS nombre_curso, p.nombre_profesor AS nombre_profesor\n" +
//                        "FROM alumnos a\n" +
//                        "INNER JOIN colegio co ON a.id_colegio = co.id_colegio\n" +
//                        "INNER JOIN cursos cu ON a.id_colegio = cu.id_colegio\n" +
//                        "INNER JOIN profesores p ON a.id_colegio = p.id_colegio\n" +
//                        "WHERE a.id_alumnos = '?';";//escribir query con JOIN
                Alumnos alumno = null;
                String mensaje ="";
                String query = "SELECT * FROM alumnos where id_alumnos = " + id_alumno ;
                 try { ResultSet rs = conn.createStatement().executeQuery(query);
                     if (rs.next()) {
                         alumno = new Alumnos(
                                 rs.getInt("id_alumnos"),
                                 rs.getInt("id_colegio"),
                                 rs.getString("nombre"),
                                 rs.getString("apellido")                
                         );
                     }
                     
                 } catch (SQLException ex) {
                     Logger.getLogger(AlumnoImpl.class.getName()).log(Level.SEVERE, null, ex);
                 }
                 
                  if (alumno != null) {
                         
                          mensaje =
                                 
                                 "Id_alumno: " + alumno.getId_alumnos() +
                                 "\n Id_colegio: " + alumno.getId_colegio() +
                                 "\n nombre: " + alumno.getNombre()+
                                 "\n apellido: " + alumno.getApellido()
                                 ;
                         
                     }
                  return mensaje;
  
            
    }

    @Override
    public void update(Alumnos alumno) {
        
    }

    @Override
    public void delete(Alumnos alumno) {
       String query = "delete  from alumnos where id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, alumno.getId_alumnos());
            ps.executeUpdate();
            /*!!!!!!ESTE BLOQUE ESTA A REVISION¡¡¡¡¡
            puede que no sea el metodo mas OPTIMO, revisar CONNECTION POOL*/
           try {
               Conexion.cerrarConexion(conn);
               System.out.println("la sesion cerro correctamente¡¡¡¡");
           } catch (IOException ex) {
               Logger.getLogger(AlumnoImpl.class.getName()).log(Level.SEVERE, null, ex);
           }
           /*!!!!!!ESTE BLOQUE ESTA A REVISION¡¡¡¡¡*/
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    

}
