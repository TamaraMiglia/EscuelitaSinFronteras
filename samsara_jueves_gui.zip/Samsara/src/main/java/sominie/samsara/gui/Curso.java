

package sominie.samsara.gui;


public class Curso {
    public static void main(String[] args) {
        
    }

}
