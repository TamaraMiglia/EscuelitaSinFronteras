   package sominie.samsara.java.daoImpl;


import sominie.samsara.java.connectors.Conexion;
import sominie.samsara.java.entities.Alumnos;
import sominie.samsara.java.interfaces.I_Alumno;
import java.sql.PreparedStatement;



public class AlumnoImpl implements I_Alumno {

    private Conexion conn;

    public AlumnoImpl(Conexion conn) {
        this.conn = conn;
        
    }

    @Override
    public void add(Alumnos alumno) {
           String query = "DELETE FROM productos WHERE codigo = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
           // ps.setInt(1, producto.getCodigo());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void search(Alumnos alumno) {
        
    }

    @Override
    public void update(Alumnos alumno) {
        
    }

    @Override
    public void delete(Alumnos alumno) {
        
    }

    

}
