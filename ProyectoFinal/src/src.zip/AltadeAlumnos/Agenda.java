/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AltadeAlumnos;
import InterfazGrafica.Alta;
/**
 *
 * @author pc
 */
public class Agenda {
    public static void main(String[] args) {
        Alta a = new Alta();
        a.setVisible(true);
    }
}
