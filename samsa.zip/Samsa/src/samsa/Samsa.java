
package samsa;

public class Samsa {

 
    public static void main(String[] args) {
       
    }
    
}
