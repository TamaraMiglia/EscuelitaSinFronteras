 package sominie.samsara.java.daoImpl;
//import sominie.samsara.java.connectors.Conexion;
import java.io.IOException;
import sominie.samsara.java.entities.Alumnos;
import sominie.samsara.java.interfaces.I_Alumno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sominie.samsara.java.connectors.Conexion;



public class AlumnoImpl implements I_Alumno {

    private Connection conn;

    
    public AlumnoImpl(Connection conn) {
        this.conn = conn;
        
    }

    @Override
    public void add(Alumnos alumno) {
        try {
            String query = "INSERT INTO alumnos (id_colegio, nombre, apellido) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
           // ps.setInt(1, alumno.getId_alumnos());
            ps.setInt(1, alumno.getId_colegio());/*aqui como debo tratar al dato? lo mando a llamar de algun lado o lo caoturo por pantalla?*/
            ps.setString(2, alumno.getNombre());
            ps.setString(3, alumno.getApellido());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AlumnoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }

    @Override
    public void getOne(Alumnos alumno) {
       
    }

    @Override
    public void update(Alumnos alumno) {
        
    }

    @Override
    public void delete(Alumnos alumno) {
       String query = "delete  from alumnos where id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, alumno.getId_alumnos());
            ps.executeUpdate();
            /*!!!!!!ESTE BLOQUE ESTA A REVISION¡¡¡¡¡
            puede que no sea el metodo mas OPTIMO, revisar CONNECTION POOL*/
           try {
               Conexion.cerrarConexion(conn);
               System.out.println("la sesion cerro correctamente¡¡¡¡");
           } catch (IOException ex) {
               Logger.getLogger(AlumnoImpl.class.getName()).log(Level.SEVERE, null, ex);
           }
           /*!!!!!!ESTE BLOQUE ESTA A REVISION¡¡¡¡¡*/
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    

}
