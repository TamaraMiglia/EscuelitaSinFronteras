
package sominie.samsara.java.interfaces;

import sominie.samsara.java.entities.Alumnos;
import java.util.List;
import sominie.samsara.java.entities.Cursos;

public interface I_Alumno {
    
    public void add(Alumnos alumno); 
    public void getOne(Alumnos alumno);
    public void update(Alumnos alumno);
    public void delete(Alumnos alumno);
   // public List<Cursos> cursoActual();
}
