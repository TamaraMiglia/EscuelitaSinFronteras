

package sominie.samsara.java.daoImpl;

import com.sun.jdi.connect.spi.Connection;
import sominie.samsara.java.interfaces.I_Cursos;
import java.sql.PreparedStatement;


public class CursosImpl implements I_Cursos {
        private Connection  conn;
        
        public CursosImpl (Connection conn) {
        this.conn= conn;
        }

    @Override
    public void add() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void getOne(int id_colegio) {
        
        //configurar la QUERY correcta !!!!!!!!!!!
        //verificar lo que s ele esta pasando a SetInt()
        String query = "SELECT curso FROM cursos where id_colegio = ? ";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.SetInt(1,id_colegio);
        ps.executeUpdate();
        
    }

    @Override
    public void update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    }


   

