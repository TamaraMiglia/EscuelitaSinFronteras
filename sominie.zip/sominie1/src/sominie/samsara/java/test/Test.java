

package sominie.samsara.java.test;

import sominie.samsara.java.connectors.Conexion;
import java.sql.Connection;
import sominie.samsara.java.connectors.Conexion;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import sominie.samsara.gui.FormAlumnos;
import sominie.samsara.java.daoImpl.AlumnoImpl;
import sominie.samsara.java.entities.Alumnos;
import sominie.samsara.java.interfaces.I_Alumno;


public class Test {
    public static void main(String[] args) throws IOException, SQLException {
        
           
        
        // Crear la instancia de la conexión a la base de datos
        Connection conn = (Connection) Conexion.getConnection();

        // Crear una instancia de ProductoDAOImpl
        I_Alumno al = new AlumnoImpl((java.sql.Connection) conn);
//
//        // Insertar un nuevo producto
////        Producto nuevoProducto = new Producto(1, "Televisor", "Sony", 499.99, 10);
////       
////        dao.insertarProducto(nuevoProducto);
//
//        // Listar todos los productos
////        List<Producto> productos = dao.listarProductos();
////        for (Producto producto : productos) {
////            System.out.println(producto);
////        }
//
//        // Actualizar el stock del producto con código 1
//        Producto productoExistente = new Producto(1, "Televisor", "Sony", 499.99, 30);
//        dao.actualizarProducto(productoExistente);
//
////         Eliminar el producto con código 1
////        dao.eliminarProducto(productoExistente);
//
//        // Cerrar la conexión a la base de datos
//        Conexion.cerrarConexion((java.sql.Connection) conn);
            
            Alumnos al1 = new Alumnos(5);
            al.delete(al1);
            Conexion.cerrarConexion((java.sql.Connection) conn);

   }
}
